# SoupTalk
Maptime Seattle tutorial: using Beautiful Soup to extract geodata from websites
